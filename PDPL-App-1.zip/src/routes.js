const routes = [
    { path: '/', exact: true, component: 'Home' },
    { path: '/about', component: 'About' },
    { path: '/contact', component: 'Contact' },
  ];
  
  module.exports = routes;